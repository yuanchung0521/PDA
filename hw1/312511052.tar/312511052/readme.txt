# PDA hw1

This is the first homework, wwhich implement the FM partition method.

## Project Structure

- `main.cpp`: Main program source code file.
- `classtype.h`: Header file containing custom data structures and types used in the project.
- `Makefile`: Makefile for building the project.

## How to Build

1. In the terminal, navigate to the root directory of the project.
2. Run the following command to build the project:

```bash
make